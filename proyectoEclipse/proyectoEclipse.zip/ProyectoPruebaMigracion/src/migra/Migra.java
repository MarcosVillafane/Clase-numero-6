package migra;

public class Migra {

	public static void main(String[] args) {
		System.out.println("Hola a todos");
		System.out.println("Esta es mi pequeña prueba de migracion");
	}
}
